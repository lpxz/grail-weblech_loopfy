package edu.hkust.cse.phoneAdapter.context;

/**
 * The Interface ContextOperator.
 * @author andrew
 */
public interface ContextOperator {
	
	public final static int EQUAL=1;
	
	public final static int NOTEQUAL=2;
	
	public final static int GREATER=3;
	
	public final static int GREATER_EQUAL=4;
	
	public final static int SMALLER=5;
	
	public final static int SMALLER_EQUAL=6;
}
