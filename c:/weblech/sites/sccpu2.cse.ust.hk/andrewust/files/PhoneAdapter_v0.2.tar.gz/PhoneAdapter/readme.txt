This project aim at developing a context aware adaptive application called PhoneAdapter for Android platform primarily for research purposes.
Author: Yepang Liu
Email: yepangliu@gmail.com

Please note that we do not provide any warranty about the software's quality. For any enquiry, please kindly contact the author. We sincerely welcome researchers and practitioners who are interested to join this project.

  
